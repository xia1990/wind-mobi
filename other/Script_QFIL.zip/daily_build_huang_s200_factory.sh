#!/bin/bash

WsRootDir=`pwd`
MY_NAME=`whoami`
PRO_PATH=$WsRootDir/factory_s200x_project
OUT_PATH=$PRO_PATH/out/target/product/msm8937_64
DESTINATION_PATH=$PRO_PATH/NOHLOS/LA.UM.6.6/LINUX/android/out/target/product/msm8937_64
SPARSE_PATH=$PRO_PATH/NOHLOS/MSM8937.LA.3.0.1/common/build/bin/asic/sparse_images
NOHLOS_PATH=$PRO_PATH/NOHLOS
VMLINUX_PATH=$OUT_PATH/obj/kernel/msm-3.18/vmlinux
CPUCORE=8

COMPILER_TOGGLE=t
#1.选择操作指令 2.选择要编译的版本 3.选择项目平台库
MY_PATTERN=$1
NEED_BUILD_VERSION=$2
PLALFORM_LIBRARY=$3
Daily_Date=`date +%m%d`


function main()
{
    #echo "##################################################################"
    #echo "######################选择你要操作的指令##########################"
    #echo "#  1、拉代码"
    #echo "#  2、编译"
    #echo "#  3、拉代码+编译"
    #echo "##################################################################"

    #判断S200X_project文件夹是否存在，存在删除，不存在创建
    echo $PRO_PATH
    if [ ! -d $PRO_PATH ];then
    	echo "不存在"
        mkdir $PRO_PATH
    else
        echo "存在"
        rm -rf $PRO_PATH
        mkdir $PRO_PATH
    fi
    
    cd $PRO_PATH
    echo `pwd`
    
    if [ x$MY_PATTERN == x"1" ] ; then
    	pull_code
    elif [ x$MY_PATTERN == x"2" ] ;then
        #echo "####################选择要编译的版本######################"
        #echo "#  user       user"
        #echo "#  userdebug  userdebug"
        #echo "#  eng        eng"
        original_build
        release_verison
    elif [ x$MY_PATTERN == x"3" ] ;then
        echo "####################选择要编译的版本######################"
        #echo "#  user       user"
        echo "#  userdebug  userdebug"
        echo "#  eng        eng"
        pull_code
        original_build
        release_verison
	make_NOHLOS
	packaging_version
    else
        echo "check you choose is right?"
        exit 0
    fi
}

function release_verison()
{
    echo "################ release_verison start ####################"
    cd ./out/target/product/msm8937_64
    #cp *.img *.mbn /data/mine/test/MT6572/$MY_NAME
    echo "################  release_verison end  ####################"
}

function original_build()
{
    #echo "####################### build start #######################"
    #准备编译环境
    #source build/envsetup.sh
    #lunch 选择版本
    #if [ x$NEED_BUILD_VERSION == x"userdebug" ] ; then
    #	echo "build version is userdebug"
    #	lunch msm8953_64-userdebug
	#elif [ x$NEED_BUILD_VERSION == x"eng" ] ; then
	#	echo "build version is eng"
	#	choosecombo release msm8953_64 eng
	#else
	#	echo "build version is userdebug"
	#	lunch msm8953_64-userdebug
	#fi
	#
	#make -j$CPUCORE 2>&1 | tee $LOG_PATH.log
	#echo "####################### build end #########################"
    
    #echo $WsRootDir
    #echo "编译开始"
    sed -i 's/CPUCORE=8/CPUCORE=32/' $PRO_PATH/quick_build.sh
    DAILYBUILD_NUMBER_FACTORY="IFL-S200X_V1.0B16_SMT_"$Daily_Date
    echo $DAILYBUILD_NUMBER_FACTORY
    sed -i 's/$BUILD_DISPLAY_ID/$DAILYBUILD_NUMBER_FACTORY/' $PRO_PATH/wind/custom_files/build/tools/buildinfo.sh
    #编译指令
    ./quick_build.sh S200X debug new fc 
    
}

function pull_code()
{
    echo "####################### pull code start #######################"
    #如果平台库PLALFORM_LIBRARY为空，默认为LNX_LA_MSM8953_PSW（owl项目）
    if [ x$PLALFORM_LIBRARY == x"" ] ; then
    	PLALFORM_LIBRARY=LNX_LA_MSM8937_S200X-U100C_PSW
    fi
    
    repo init -u ssh://$MY_NAME@10.0.30.10:29418/$PLALFORM_LIBRARY/Manifest -m manifest.xml -b S200X_Factory_BRH  --repo-url=ssh://$MY_NAME@10.0.30.10:29418/Tools/Repo --no-repo-verify
    
    if [ ! -f ./.repo/manifest.xml ] ;then
        echo "repo init failed"
        echo "check repo path ssh://$MY_NAME@10.0.30.10:29418/$PLALFORM_LIBRARY  is right?"
    	exit 0
    fi
    
    echo "start to edit ~/$LocalFolderPATH/.repo/manifest.xml"
    #修改.repo/manifest.xml，将itadmin替换为自己的名字
    sed -i 's/itadmin/'"$MY_NAME"'/' ./.repo/manifest.xml
    
    
    #更新代码，创建分支
    repo sync -j4
    echo "start to repo sync"
    repo start S200X_Factory_BRH --all
    echo "####################### pull code end #########################"
}

#编译N测代码
function make_NOHLOS(){
    cd NOHLOS/
    echo "start to build NOHLOS"
    ./build_n.sh all | tee nohlos.log
    echo "################make_NOHLOS end############# "
}

function packaging_version(){
    if [ ! -d $DESTINATION_PATH ];then
    	mkdir -p $DESTINATION_PATH
    else 
	rm -rf $DESTINATION_PATH/*
    fi

    if [ -d $SPARSE_PATH ] ;then
    	rm -rf $SPARSE_PATH/*
    fi

    if [ -d $OUT_PATH ];then
   	echo "out path:"$OUT_PATH""
   	cd $OUT_PATH
   	cp *.img *.mbn $DESTINATION_PATH
   	cp $VMLINUX_PATH $DESTINATION_PATH
    else 
    	echo "out path not exist!"
   	exit
    fi

    cd $NOHLOS_PATH
    ./cpn
    cd out/
    #在此处需要将最新的N测的切片文件拷贝到当前目录下
    cp ~/FACTORY_NOHLOS/* .
    rm FlashPackage_S200X-U100C_QFIL.zip
    zip factory_QFIL.zip ./*
    cp factory_QFIL.zip /data/mine/test/MT6572/gaoyuxia/
}

###################MAIN##################
main $1 $2 $3
