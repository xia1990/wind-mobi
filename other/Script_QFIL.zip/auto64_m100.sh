#!/bin/bash

WsRootId=`pwd`
name=`whoami`
OUT_PATH=$WsRootId/owl_project/out/target/product/msm8953_64
SPARSE_PATH=$WsRootId/M100_N/NOHLOS/MSM8953.LA.2.0/common/build/bin/asic/sparse_images
NCODE_PATH=$WsRootId/M100_N/NOHLOS
ALL_COPY_FILE="boot.img cache.img emmc_appsboot.mbn mdtp.img persist.img ramdisk.img recovery.img system.img userdata.img"
DESTINATION_PATH=$WsRootId/M100_N/NOHLOS/LA.UM.5.6/LINUX/android/out/target/product/msm8953_64
CREATE_PATH_ROOT=$WsRootId/M100_N/NOHLOS/LA.UM.5.6/LINUX/android/

if [ ! -d $DESTINATION_PATH ];then
  mkdir -p $CREATE_PATH_ROOT/out/target/product/msm8953_64
else
  rm -rf $DESTINATION_PATH/*
fi

if [ -d $OUT_PATH ];then
   echo "out path:"$OUT_PATH""
   cd $OUT_PATH
else 
   echo "out path not exist!"
   exit
fi

for i in $ALL_COPY_FILE
do
    if [ -f $i ]; then
    	cp $i  $DESTINATION_PATH
    else 
	echo ""$i" not exist !!!"
	exit
    fi
done

if [ -d $SPARSE_PATH ];then
    rm -rf $SPARSE_PATH/*
fi

cd $NCODE_PATH
echo "change to NCODE_PATH:"$NCODE_PATH""
./cpn
#cp compress.pl out/
cd out/
#perl compress.pl FlashPackage.zip
#mv FlashPackage.zip M100_QFIL.zip
cp FlashPackage_M101_QFIL.zip /data/mine/test/MT6572/$name
