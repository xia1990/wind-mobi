echo "开如构建时间: `date +%Y%m%d_%H%M%S`" >/home1/gaoyuxia/s200dailybuild/factory_s200x/factory_s200x_daily_build_log.log

export USER=`whoami`
USER_PATH=/home1/gaoyuxia/s200dailybuild/factory_s200x
echo $USER_PATH
cd $USER_PATH
#TODO 1.选择操作指令 2.选择要编译的版本 3.选择项目平台库
./daily_build_huang.sh 3 userdebug LNX_LA_MSM8937_S200X-U100C_PSW

echo "结束构建时间: `date +%Y%m%d_%H%M%S`" >/home1/gaoyuxia/s200dailybuild/factory_s200x/factory_s200x_daily_build_log.log
