echo "开始构建时间： `date +%Y%m%d_%H%M%S`" >>/home1/gaoyuxia/s200dailybuild/owl/owl_daily_build_log.log

export USER=`whoami`
USER_PATH=/home1/gaoyuxia/s200dailybuild/owl
echo "#####@@@@"
echo $USER_PATH
echo "#####@@@@"
cd $USER_PATH

#TODO 1.选择操作指令 2.选择要编译的版本 3.选择项目平台库
./daily_build_huang.sh 3 userdebug LNX_LA_MSM8953_OWL_PSW

echo "结束构建时间： `date +%Y%m%d_%H%M%S`" >>/home1/gaoyuxia/s200dailybuild/owl/owl_daily_build_log.log
