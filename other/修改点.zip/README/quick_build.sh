#!/bin/bash
#######################################################################################################################
###      编译命令: AP端默认编译deubug版本，如需编译其它版本，请添加对应参数（user,eng,默认debug）                  ####
###           all: ./quick_build.sh M500N   all                                                                    ####
###          amss: ./quick_build.sh M500N   AMSS                                                                   ####
##          AP端:  ./quick_build.sh M500N   AP                                                                      ####
###          boot: ./quick_build.sh M500N   BOOT                                                                   ####
###          mpss: ./quick_build.sh M500N   MPSS                                                                   ####
###            tz: ./quick_build.sh M500N   TZ                                                                     ####
###          adsp: ./quick_build.sh M500N   ADSP                                                                   ####
###        common: ./quick_build.sh M500N   COMMON                                                                 ####
###    AP端kernel: ./quick_build.sh M500N   k                                                                      ####
#######################################################################################################################


WsRootDir=`pwd`
MY_NAME=`whoami`
amssPath=$WsRootDir/NOHLOS
#CONFIGPATH=$WsRootDir/device/ginreen
ARM=arm64
#KERNELCONFIGPATH=$WsRootDir/kernel-3.18/arch/$ARM/configs
#CUSTOMPATH=$WsRootDir/device/ginreen
#BUILDINFO=$WsRootDir/build-log/buildinfo
#RELEASE_PARAM=all
LOG_PATH=$WsRootDir/build-log
#BASE_PRJ=gr6750_66_r_n
#Mode_Path=$WsRootDir/vendor/mediatek/proprietary/modem/gr6750_66_r_n_lwctg_mp5
CPUCORE=8

PRODUCT=
VARIANT=
ACTION=
MODULE=
ORIGINAL=
COPYFILES=

clean_pl()
{
    if [ x$ORIGINAL == x"yes" ]; then
        rm $LOG_PATH/pl.log; make clean-pl
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        PL_OUT_PATH=$OUT_PATH/obj/PRELOADER_OBJ
        rm -f $LOG_PATH/pl.log
        rm -f $OUT_PATH/preloader_$PRODUCT.bin
        rm -rf $PL_OUT_PATH
        result=$?
        return $result
    fi
}

build_pl()
{
    if [ x$ORIGINAL == x"yes" ]; then
        make -j$CPUCORE pl 2>&1 | tee $LOG_PATH/pl.log
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        PL_OUT_PATH=$OUT_PATH/obj/PRELOADER_OBJ
        cd vendor/mediatek/proprietary/bootable/bootloader/preloader
        PRELOADER_OUT=$PL_OUT_PATH TARGET_PRODUCT=$PRODUCT ./build.sh 2>&1 | tee $LOG_PATH/pl.log
        result=$?
        cd -
        cp $PL_OUT_PATH/bin/preloader_$PRODUCT.bin $OUT_PATH
        return $result
    fi
}

clean_kernel()
{
    if [ x$ORIGINAL == x"yes" ]; then
        rm $LOG_PATH/k.log; make clean-kernel
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        KERNEL_OUT_PATH=$OUT_PATH/obj/KERNEL_OBJ
        rm -f $LOG_PATH/k.log
        rm -f $OUT_PATH/boot.img
        rm -rf $KERNEL_OUT_PATH
        result=$?
        return $result
    fi
}

build_kernel()
{
    if [ x$ORIGINAL == x"yes" ]; then
        make -j$CPUCORE kernel 2>&1 | tee $LOG_PATH/k.log
        return $?
    else
        cd kernel-3.18
        if [ x$VARIANT == x"user" ] || [ x$VARIANT == x"userroot" ];then
            defconfig_files=${PRODUCT}_defconfig
        else
            defconfig_files=${PRODUCT}_debug_defconfig
        fi
        KERNEL_OUT_PATH=../out/target/product/$PRODUCT/obj/KERNEL_OBJ
        mkdir -p $KERNEL_OUT_PATH
        while [ 1 ]; do
            make O=$KERNEL_OUT_PATH ARCH=$ARM ${defconfig_files}
            result=$?; if [ x$result != x"0" ];then break; fi
            #make -j$CPUCORE -k O=$KERNEL_OUT_PATH Image modules
            make -j$CPUCORE O=$KERNEL_OUT_PATH ARCH=$ARM CROSS_COMPILE=$WsRootDir/prebuilts/gcc/linux-x86/aarch64/aarch64-linux-android-4.9/bin/aarch64-linux-android- 2>&1 | tee $LOG_PATH/k.log
            result=$?; if [ x$result != x"0" ];then break; fi
            cp $KERNEL_OUT_PATH/arch/$ARM/boot/zImage-dtb ../out/target/product/$PRODUCT/kernel
            break
        done
        cd -
        return $result
    fi
}

clean_lk()
{
    if [ x$ORIGINAL == x"yes" ]; then
        rm $LOG_PATH/lk.log; make clean-lk
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        LK_OUT_PATH=$OUT_PATH/obj/BOOTLOADER_OBJ
        rm -f $LOG_PATH/lk.log
        rm -f $OUT_PATH/lk.bin $OUT_PATH/logo.bin
        rm -rf $LK_OUT_PATH
        result=$?
        return $result
    fi
}

build_lk()
{
    if [ x$ORIGINAL == x"yes" ]; then
        make -j$CPUCORE lk 2>&1 | tee $LOG_PATH/lk.log
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        LK_OUT_PATH=$OUT_PATH/obj/BOOTLOADER_OBJ
        mkdir -p $LK_OUT_PATH
        cd vendor/mediatek/proprietary/bootable/bootloader/lk
        export BOOTLOADER_OUT=$LK_OUT_PATH
        export MTK_PUMP_EXPRESS_SUPPORT=yes
        make -j$CPUCORE $PRODUCT 2>&1 | tee $LOG_PATH/lk.log
        result=$?
        cd -
        cp $LK_OUT_PATH/build-$PRODUCT/lk.bin $OUT_PATH
        cp $LK_OUT_PATH/build-$PRODUCT/logo.bin $OUT_PATH
        return $result
    fi
}

function build_boot_image(){
    echo "========== build BOOT.XF.2.1 =========="
    cd $amssPath/BOOT.XF.2.1/boot_images/QcomPkg/SDM670Pkg/
    echo "start build boot_image"
    if [ x$CLEAN == x"c" ];then
        #./build.sh TARGET_FAMILY=8953 --prod -c
        python ../buildex.py --variant LA -r RELEASE -t SDM670Pkg,QcmToolsPkg --build_flags=cleanall
    else
        python ../buildex.py --variant LA -r RELEASE -t SDM670Pkg,QcomToolsPkg  2>&1|tee $LOG_PATH/boot.log
        #if [ "`grep "Successfully compile 8953" $LOG_PATH/boot.log`"  ];then
        #   echo -e "\033[40;32m Build BOOT.XF.2.1 Successfully \033[0m"
        #   sleep 2
        #else
        #    echo -e "\033[40;31m Build BOOT.XF.2.1 failed (>.<) \033[0m"
        #   exit 1
        #fi
    fi
	cd -
}

function build_mpss(){
    echo "========== build MPSS.AT.4.0.2 =========="
    echo -e "\033[40;32mCompile modem is $MODEM \033[0m"
    cd $amssPath/MPSS.AT.4.0.2/modem_proc/build/ms
    echo "set environment"
    source ./setenv.sh
    echo "start build mpss"
    if [ x$CLEAN == x"c" ];then
        #./build.sh 8953.genw3k.prod -c
		./build_variant.py sdm710.gennm.prod --clean
    else
        python build_variant.py sdm710.gennm.prod bparams=-k  2>&1|tee $LOG_PATH/mpss.log
        #if [ "`grep "Build 8953.genw3k.prod returned code 0" $LOG_PATH/mpss.log`"  ];then
        #   echo -e "\033[40;32m Build MPSS.AT.4.0.2 Successfully \033[0m"
        #   sleep 2
        #else
        #   echo -e "\033[40;31m Build MPSS.AT.4.0.2 failed (>.<) \033[0m"
        #   exit 1
        #fi
    fi
	cd -
}

function build_aop(){
    echo "========== build AOP.HO.1.1 =========="
    cd $amssPath/AOP.HO.1.1/aop_proc/build
    #source ./setenv.sh
    if [ x$CLEAN == x"c" ];then
       # ./build_8953.sh -c
	   ./build_670.sh -c
    else
        ./build_670.sh   2>&1|tee $LOG_PATH/aop.log
        #if [ "`grep "done building targets" $LOG_PATH/aop.log`" ];then
        #    echo -e "\033[40;32m Build AOP.HO.1.1 Successfully \033[0m"
        #    sleep 2
        #else
        #    echo -e "\033[40;31m Build AOP.HO.1.1 failed (>.<) \033[0m"
        #    exit 1
        #fi
    fi
	cd -
}

function build_tz(){
    echo "========== build TZ.XF.5.0 =========="
    cd $amssPath/TZ.XF.5.0/trustzone_images/build/ms
    if [ x$CLEAN == x"c" ];then
        #./build.sh CHIPSET=msm8953 devcfg sampleapp -c
		python build_all.py -b TZ.XF.5.0 CHIPSET=sdm670 config=build_config_deploy.xml --clean
    else
        python build_all.py -b TZ.XF.5.0 CHIPSET=sdm670 --config=build_config_deploy.xml --recompile  2>&1|tee $LOG_PATH/tz.log
        #if [ "`grep "done building targets" $LOG_PATH/tz.log`" ];then
        #    echo -e "\033[40;32m Build TZ.XF.5.0 Successfully \033[0m"
        #    sleep 2
        #else
        #    echo -e "\033[40;31m Build TZ.XF.5.0 failed (>.<) \033[0m"
        #    exit 1
        #fi
    fi
	cd -

}

function build_cdsp()
{
    echo "========== build CDSP.VT.2.0 =========="
    cd $amssPath/CDSP.VT.2.0
    if [ x$CLEAN == x"c" ];then
        #./build.sh CHIPSET=msm8953 devcfg sampleapp -c
		python ./cdsp_proc/build/build.py -c sdm670 -o clean -f CDSP
    else
        python ./cdsp_proc/build/build.py -c sdm670 -o all -f CDSP   2>&1|tee $LOG_PATH/cdsp.log
        #if [ "`grep "done building targets" $LOG_PATH/cdsp.log`" ];then
        #    echo -e "\033[40;32m Build CDSP.VT.2.0 Successfully \033[0m"
        #    sleep 2
        #else
        #    echo -e "\033[40;31m Build CDSP.VT.2.0 failed (>.<) \033[0m"
        #    exit 1
        #fi
    fi
	cd -
}

function build_adsp(){
    echo "========== ADSP.VT.5.0 =========="
    cd $amssPath/ADSP.VT.5.0/adsp_proc
    #source ./setenv.sh
    if [ x$CLEAN == x"c" ];then
       # python ./build/build.py -c msm8953 -o clean
	   python ./adsp_proc/build/build.py -c sdm670 -o clean -f aDSP
    else
        python ssc/build/config_nanopb_dependency.py -f nanopb-0.3.6-linux-x86
        python build/build.py -c sdm670 -f ADSP -o all
        #if [ "`grep "Compilation SUCCESS" $LOG_PATH/adsp.log`" ];then
        #   echo -e "\033[40;32m Build ADSP.VT.5.0 Successfully \033[0m"
        #   sleep 2
        #else
        #   echo -e "\033[40;31m Build ADSP.VT.5.0 failed (>.<) \033[0m"
        #    exit 1
        #fi
    fi
	cd -
}

#build common
function build_common(){
    echo "========== SDM670.LA.1.0 =========="
    echo "make download files"
    if [ x$CLEAN != x"c" ];then
            cd $amssPath/SDM670.LA.1.0/common/build
            python build.py $PRODUCT 2>&1|tee $LOG_PATH/common.log


        #if [ "`grep "UPDATE COMMON INFO COMPLETE" $LOG_PATH/common.log`" ];then
        #        echo -e "\033[40;32m Build SDM670.LA.1.0 Successfully \033[0m"
        #        sleep 2
        #    else
        #        echo -e "\033[40;31m Build SDM670.LA.1.0 failed (>.<) \033[0m"
        #        exit 1

        #fi
	    cd -
    fi
	
}

function build_amss()
{
    echo "build all in amss"
    build_boot_image
    build_mpss
    #build_rpm
    build_tz
    build_adsp
    build_cdsp
    build_aop
    echo -e "\033[40;32mmoudles in amss build finished \033[0m"
    if [ -d "$WsRootDir/out/target/product/$PRODUCT" ];then
    build_common
    fi
}

# restore code in same as before 
revert_code()
{
    echo -e "\033[33mIt's going to revert your code.\033[0m"
    read -n1 -p  "Are you sure? [Y/N]" answer
    case $answer in
        Y | y )
        echo "";;
        *)
    echo -e "\n"
        exit 0 ;;
    esac
   echo "Start revert Code...."
   echo "repo forall -c \"git clean -df\""
   repo forall -c  "git clean -df"
   echo "repo forall -c \"git co .\""
   repo forall -c "git co ."
   echo "rm -rf $LOG_PATH/*"
   rm -rf $LOG_PATH/*
   echo "rm -rf out"
   rm -rf out
   echo -e "\033[33mComplete revert code.\033[0m"

}

function analyze_args()
{
    ### set PRODUCT
    PRODUCT=$1

    case $PRODUCT in
        M500N )
        echo "PRODUCT=$PRODUCT"
        PRODUCT=sdm710
        RELEASEPATH=sdm710
        ORIGINAL=yes
        ;;

        *)
        echo "PRODUCT name error $PRODUCT!!!"
        exit 1
        ;;
    esac

    command_array=($2 $3 $4 $5)

    for command in ${command_array[*]}; do
        ### set VARIANT
        if [ x$command == x"user" ] ;then
            if [ x$VARIANT != x"" ];then continue; fi
            VARIANT=user
        elif [ x$command == x"debug" ] ;then
            if [ x$VARIANT != x"" ];then continue; fi
            VARIANT=userdebug
        elif [ x$command == x"eng" ] ;then
            if [ x$VARIANT != x"" ];then continue; fi
            VARIANT=eng
        elif [ x$command == x"userroot" ] ;then
            if [ x$VARIANT != x"" ];then continue; fi
            VARIANT=userroot

        ### set ACTION
        elif [ x$command == x"r" ] || [ x$command == x"remake" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=remake
        elif [ x$command == x"n" ] || [ x$command == x"new" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=new
        elif [ x$command == x"c" ] || [ x$command == x"clean" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=clean
            RELEASE_PARAM=none
        elif [ x$command == x"m" ] || [ x$command == x"make" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=m
            RELEASE_PARAM=none
        elif [ x$command == x"revert" ] ;then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=revert
            RELEASE_PARAM=none
        elif [ x$command == x"mmma" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=mmma
            RELEASE_PARAM=none
        elif [ x$command == x"mmm" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=mmm
            RELEASE_PARAM=none
        elif [ x$command == x"api" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=update-api
            RELEASE_PARAM=none
        elif [ x$command == x"boot" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=bootimage
            RELEASE_PARAM=boot
        elif [ x$command == x"system" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=systemimage
            RELEASE_PARAM=system
        elif [ x$command == x"userdata" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=userdataimage
            RELEASE_PARAM=userdata
        elif [ x$command == x"boot-nodeps" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=bootimage-nodeps
            RELEASE_PARAM=boot
        elif [ x$command == x"snod" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=snod
            RELEASE_PARAM=system
        elif [ x$command == x"userdata-nodeps" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=userdataimage-nodeps
            RELEASE_PARAM=userdata
        elif [ x$command == x"ramdisk-nodeps" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=ramdisk-nodeps
            RELEASE_PARAM=boot
        elif [ x$command == x"recovery" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=recoveryimage
            RELEASE_PARAM=recovery
        elif [ x$command == x"cache" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=cacheimage
            RELEASE_PARAM=none
        elif [ x$command == x"otapackage" ] || [ x$command == x"ota" ] ;then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=otapackage
            RELEASE_PARAM=ota
        elif [ x$command == x"otadiff" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=otadiff
            RELEASE_PARAM=none
        elif [ x$command == x"cts" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=cts
            RELEASE_PARAM=none

        ### set ORIGINAL
        #elif [ x$command == x"o" ];then
            #if [ x$ORIGINAL != x"" ];then continue; fi
            #ORIGINAL=yes

        ### set COPYFILES
        elif [ x$command == x"fc" ];then
            if [ x$COPYFILES != x"" ];then continue; fi
            COPYFILES=yes

        elif [ x$command == x"nc" ];then
            if [ x$COPYFILES != x"yes" ];then continue; fi
            COPYFILES=no

        ### set MODULE
        elif [ x$command == x"pl" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=pl
            RELEASE_PARAM=pl
        elif [ x$command == x"k" ] || [ x$command == x"kernel" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=k
            RELEASE_PARAM=boot
        elif [ x$command == x"lk" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=lk
            RELEASE_PARAM=lk
        elif [ x$command == x"AP" ] || [ x$command == x"ap" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=AP
            RELEASE_PARAM=ap
        elif [ x$command == x"AMSS" ] || [ x$command == x"amss" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=AMSS
            RELEASE_PARAM=amss
        elif [ x$command == x"ALL" ] || [ x$command == x"all" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=ALL
            RELEASE_PARAM=all
        elif [ x$command == x"BOOT" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=BOOT
            RELEASE_PARAM=boot
        elif [ x$command == x"MPSS" ] || [ x$command == x"mpss" ] ;then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=MPSS
            RELEASE_PARAM=mpss
        elif [ x$command == x"RPM" ] || [ x$command == x"rpm" ] ;then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=RPM
            RELEASE_PARAM=rpm
        elif [ x$command == x"TZ" ] || [ x$command == x"tz" ] ;then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=TZ
            RELEASE_PARAM=tz
        elif [ x$command == x"ADSP" ] || [ x$command == x"adsp" ] ;then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=ADSP
            RELEASE_PARAM=adsp
        elif [ x$command == x"CDSP" ] || [ x$command == x"cdsp" ] ;then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=CDSP
            RELEASE_PARAM=csdp
        elif [ x$command == x"AOP" ] || [ x$command == x"aop" ] ;then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=AOP
            RELEASE_PARAM=aop
        elif [ x$command == x"COMMON" ] || [ x$command == x"common" ] ;then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=COMMON
            RELEASE_PARAM=common
        else
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=$command
        fi
    done

    if [ x$VARIANT == x"" ];then VARIANT=eng; fi
    #if [ x$ORIGINAL == x"" ];then ORIGINAL=no; fi
    if [ x$ACTION == x"clean" ];then RELEASE_PARAM=none; fi
    if [ x$COPYFILES == x"" ]; then COPYFILES=no ;fi
}

function main()
{
    ##################################################################
    #Check parameters
    ##################################################################
    if [ ! -d $LOG_PATH ];then
        mkdir $LOG_PATH
    fi
   
    analyze_args $1 $2 $3 $4 $5

    if [ x$ACTION == x"revert" ];then
        revert_code
    fi

    ### Check VARIANT WHEN NOT NEW
    Check_Variant

    echo "PRODUCT=$PRODUCT VARIANT=$VARIANT ACTION=$ACTION MODULE=$MODULE COPYFILES=$COPYFILES ORIGINAL=$ORIGINAL"
    echo "Log Path $LOG_PATH"

    if [ x$ACTION == x"" ];then
        echo  -e "\033[31m !!!!!!   No Such Action =$ACTION ======!!!! \033[0m"
        exit 1
    fi

    ##################################################################
    #Prepare
    ##################################################################
    Check_Space
    CUSTOM_FILES_PATH="./wind/custom_files"

    #Lancelot -s
    if [ x$COPYFILES == x"yes" ];then
        copy_custom_files
    fi

    #lisonglin@wind-mobi.com source ./change_java.sh 1.7
    OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
    case $ACTION in
        new | remake | clean)

        M=false; C=false;
        if [ x$ACTION == x"new" ];then M=true; C=true;
        elif [ x$ACTION == x"remake" ];then
          M=true;
          find $OUT_PATH/ -name 'build.prop' -exec rm -rf {} \;
        else C=true;
        fi

        case $MODULE in
            pl)
            if [ x$C == x"true" ];then clean_pl; result=$?; fi
            if [ x$M == x"true" ];then build_pl; result=$?; fi
            ;;

            k)
            if [ x$C == x"true" ];then clean_kernel; result=$?; fi
            if [ x$M == x"true" ];then
                build_kernel; result=$?
                if [ $result -eq 0 ];then make -j$CPUCORE bootimage-nodeps; result=$?; fi
            fi
            ;;

            lk)
            if [ x$C == x"true" ];then clean_lk; result=$?; fi
            if [ x$M == x"true" ];then build_lk; result=$?; fi
            ;;
            
            AP)
            if [ x$C == x"true" ];then make clean; result=$?; fi
            if [ x$M == x"true" ];then 
            ###################################################################
            #Start build
            ###################################################################
            echo "Build started `date +%Y%m%d_%H%M%S` ..."
            echo;echo;echo;echo

            source build/envsetup.sh
            if [ x$VARIANT == x"userroot" ] ; then
                lunch $PRODUCT-user
            else
                lunch $PRODUCT-$VARIANT
            fi
            ##source mbldenv.sh
            make -j$CPUCORE 2>&1 | tee $LOG_PATH/build.log; result=$?; 
            fi
            ;;
            
            AMSS)
            if [ x$M == x"true" ];then copy_amss_files; build_amss; result=$?; fi
            ;;
            
            ALL)
            if [ x$C == x"true" ];then make clean ; result=$?; fi
            if [ x$M == x"true" ];then 
            copy_amss_files;
            build_amss; result=$?; 
			cd  $WsRootDir
            
            ###################################################################
            #Start build
            ###################################################################
            echo "Build started `date +%Y%m%d_%H%M%S` ..."
            echo;echo;echo;echo
             
            source build/envsetup.sh
            if [ x$VARIANT == x"userroot" ] ; then
                lunch $PRODUCT-user
            else
                lunch $PRODUCT-$VARIANT
            fi
            ##source mbldenv.sh
            make -j$CPUCORE 2>&1 | tee $LOG_PATH/build.log; result=$?; 
            fi
            ;;
            
            BOOT)
            if [ x$M == x"true" ];then copy_amss_files; build_boot_image; result=$?; fi
            ;;
            
            MPSS)
            if [ x$M == x"true" ];then copy_amss_files; build_mpss; result=$?; fi
            ;;
            
            RPM)
            #if [ x$M == x"true" ];then build_rpm; result=$?; fi
            ;;
            
            TZ)
            if [ x$M == x"true" ];then copy_amss_files; build_tz; result=$?; fi
            ;;
            
            ADSP)
            if [ x$M == x"true" ];then copy_amss_files; build_adsp; result=$?; fi
            ;;
            
            CDSP)
            if [ x$M == x"true" ];then copy_amss_files; build_cdsp; result=$?; fi
            ;;
            
            AOP)
            if [ x$M == x"true" ];then copy_amss_files; build_aop; result=$?; fi
            ;;
            
            COMMON)
            if [ x$M == x"true" ];then copy_amss_files; build_common; result=$?; fi
            ;;
            *)
            if [ x"$MODULE" == x"" ];then
                if [ x$C == x"true" ];then make clean; rm $LOG_PATH; fi
                if [ x$M == x"true" ];then
                    if [ x$VARIANT == x"userroot" ] ; then
                        echo "make userroot version"
                        make MTK_BUILD_ROOT=yes -j$CPUCORE 2>&1 | tee $LOG_PATH/build.log; result=$?;
                    else
                        ###################################################################
                        #Start build
                        ###################################################################
                        echo "Build started `date +%Y%m%d_%H%M%S` ..."
                        echo;echo;echo;echo
                    
                        source build/envsetup.sh
                        if [ x$VARIANT == x"userroot" ] ; then
                            lunch $PRODUCT-user
                        else
                            lunch $PRODUCT-$VARIANT
                        fi
                        ##source mbldenv.sh
                        #echo "lisonglin@wind-mobi.com make -j$CPUCORE 2>&1 | tee $LOG_PATH/build.log; result=$?;"
                        make -j$CPUCORE 2>&1 | tee $LOG_PATH/build.log; result=$?;
                    fi
                fi
            else
                echo  -e "\033[31m !!!!!!   No Such module ==$MODULE   !!!! \033[0m"
                exit 1
            fi
            ;;
        esac
        ;;

        mmma | mmm | m)
        ###################################################################
        #Start build
        ###################################################################
        echo "Build started `date +%Y%m%d_%H%M%S` ..."
        echo;echo;echo;echo
    
        source build/envsetup.sh
        if [ x$VARIANT == x"userroot" ] ; then
            lunch $PRODUCT-user
        else
            lunch $PRODUCT-$VARIANT
        fi
        ##source mbldenv.sh
        $ACTION $MODULE 2>&1 | tee $LOG_PATH/$ACTION.log; result=$?
        ;;

        update-api | bootimage | systemimage | recoveryimage | userdataimage | cacheimage | snod | bootimage-nodeps | userdataimage-nodeps | ramdisk-nodeps | otapackage | otadiff | cts)        make -j$CPUCORE $ACTION 2>&1 | tee $LOG_PATH/$ACTION.log; result=$?
        ;;
    esac

    if [ $result -eq 0 ] && [ x$ACTION == x"mmma" -o x$ACTION == x"mmm" -o x$ACTION == x"m" ];then
        echo "Start to release module ...."
        DIR=`echo $MODULE | sed -e 's/:.*//' -e 's:/$::'`
        NAME=${DIR##*/}
        TARGET=out/target/product/${PRODUCT}/obj/APPS/${NAME}_intermediates/package.apk
        if [ -f $TARGET ];then
            cp -f $TARGET /data/mine/test/MT6572/${MY_NAME}/${NAME}.apk
        fi
    elif [ $result -eq 0 ] && [ $RELEASE_PARAM != "none" ]; then
        echo "Build completed `date +%Y%m%d_%H%M%S` ..."
        #echo "Start to release version ...."
        #./release_version.sh ${RELEASEPATH} ${RELEASE_PARAM}
    fi

}

function copy_custom_files()
{
    echo "Start custom copy files..."

    cp -rf ./wind/custom_files/* ./

    echo "Copy custom files finish!"
}


function copy_amss_files()
{
    echo "Start amss copy files..."

    cp -rf ./wind/custom_files/NOHLOS/* ./NOHLOS/

    echo "Copy amss files finish!"
}

function export_Config
{
	while read line; do
		export $line
	done < ./version
	
    TIME=`date +%F`
    export RELEASE_TIME=$TIME
    export WIND_CPUCORES=$CPUCORE
	export WIND_PROJECT_NAME_CUSTOM=$PRODUCT
	export WIND_OPTR_NAME_CUSTOM=$PRODUCT
    export KERNEL_VER=alcatel-kernel
}

#checkout disk space is gt 30G 
function Check_Space()
{
    UserHome=`pwd`
    Space=0
    Temp=`echo ${UserHome#*/}`
    Temp=`echo ${Temp%%/*}`
    ServerSpace=`df -lh $UserHome | grep "$Temp" | awk '{print $4}'`

    if echo $ServerSpace | grep -q 'G'; then
        Space=`echo ${ServerSpace%%G*}`
    elif echo $ServerSpace | grep -q 'T';then
        TSpace=1
    fi

    echo -e "\033[34m Log for Space $UserHome $ServerSpace $Space !!!\033[0m"
    if [ x"$TSpace" != x"1" ] ;then
        if [ "$Space" -le "30" ];then
            echo -e "\033[31m No Space!! Please Check!! \033[0m"
            exit 1
        fi
    fi
}

# check variant is or isn't the same as input 
function Check_Variant()
{
    buildProp=$WsRootDir/out/target/product/$PRODUCT/system/build.prop
    if [ -f $buildProp ] ; then
        buildType=`grep  ro.build.type $buildProp | cut -d "=" -f 2`
        if [ x$buildType != x"user" ] && [ x$buildType != x"userdebug" ]  && [ x$buildType != x"eng" ] ; then return; fi
        if [ x$VARIANT != x$buildType ]; then
            if [ x$ACTION == x"new" ]  ; then
                if [ x$MODULE == x"k" ] || [ x$MODULE == x"pl" ] || [ x$MODULE == x"lk" ] ; then
                    echo -e "\033[35mCode build type is\033[0m \033[31m$buildType\033[35m, your input type is\033[0m \033[31m$VARIANT\033[0m"
                    echo -e "\033[35mIf not correct, Please enter \033[31mCtrl+C\033[35m to Stop!!!\033[0m"
                    for i in $(seq 9|tac); do
                        echo -e "\033[34m\aLeft seconds:(${i})\033[0m"
                        sleep 1
                    done
                    echo
                fi
            else
                echo -e "\033[35mCode build type is\033[0m \033[31m$buildType\033[35m, your input type is\033[0m \033[31m$VARIANT\033[0m"
                echo -e "\033[35mChange build type to \033[31m$buildType\033[0m"
                echo
                VARIANT=$buildType
            fi
        fi
    else
        return;
    fi
}

main $1 $2 $3 $4 $5
