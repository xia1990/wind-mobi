#!/bin/sh
#���ű���������汾ʹ�õĽű�������Ҫ�Ͽ⣬����auto_pushcode.sh
#1.һ��Ҫ����Ͱ汾��  git.list   project.list   �� manifest.xml �ŵ�ͬһ��Ŀ¼�¡�
#2.OLDPROJECTPATH=���ǵͰ汾�Ĵ����ַ�� 
#3.NEWPROJECTPATH=���Ǹ߰汾�Ĵ����ַ��
#4.ȷ�����Ͽ��������������Ͽ�Ȩ�ޡ�
#5.���ű�ֻ�ʺϱ��ط�֧��Զ�̷�֧��Ϊmaster����������������Ҫ�Ķ�Ӧ�ýű���


OLDPROJECTPATH=$1
NEWPROJECTPATH=$2
WsRootDir=`pwd`
MY_NAME=`whoami`

function main()
{
 ##################################################################
 #check the  git.list  and  project.list ok
 ##################################################################

    if [ x"$1" = "x" ] || [ x"$2" = "x" ] ;then
        echo "please add OLDPROJECTPATH or NEWPROJECTPATH"
        exit 1
    fi
    echo "OLDPROJECTPATH=$OLDPROJECTPATH NEWPROJECTPATH=$NEWPROJECTPATH" 
    
    #rm_old_code
    #rm_new_git
    cp_code
    #add_push
    #creat_remote
    #remove_git
    #init_add
    #git_remote
    #git_push
    #manifest
}

function rm_old_code()
{
echo "start delete old code except .git"
i=1
cat $WsRootDir/project.list | while read LINE
do
    echo $i 
    cd $OLDPROJECTPATH/"$LINE"
    #cd ~/code/MT6753/fanghui/hui/code_test/$LINE
    let "i++"
    echo "$LINE==$i"
    ls | grep -v ".git" | xargs rm -rf
    cd -
done
echo "finish delete old code except .git"
}

function rm_new_git()
{
echo "start delete new code .git"
i=1
cat $WsRootDir/project.list | while read LINE
do
    echo $i 
    cd $NEWPROJECTPATH/"$LINE"
    #cd ~/code/MT6753/fanghui/hui/code_test/$LINE
    let "i++"
    echo "$LINE==$i"
    rm -rf .git
    cd -
done
echo "finish delete new code .git"
}

function cp_code()
{
echo "start copy new code to old"
i=1
cat $WsRootDir/project.list | while read LINE
do
    echo $i 
    cd $NEWPROJECTPATH/"$LINE"/
    #cd ~/code/MT6753/fanghui/hui/code_test/$LINE
    let "i++"
    echo "$LINE==$i"
    cp -a ./* ~/$OLDPROJECTPATH/"$LINE"
    cd -
done
echo "finish copy new code to old"
}

function add_push()
{
echo "start push code"
i=1
cat $WsRootDir/project.list | while read LINE
do
    echo $i 
    cd $OLDPROJECTPATH/"$LINE"
    #cd ~/code/MT6753/fanghui/hui/code_test/$LINE
    let "i++"
    echo "$LINE==$i"
    git add -A -f
    git commit -m "update version"
    #git push origin  master:master
    cd -
done
echo "finish push code"
}

function creat_remote()
{
echo "start creat_remote" 
line=$(sed -n "$=" $WsRootDir/gitnew.list)
echo "$line"
for((i=1;i<="$line";i++));
do
        a=$(sed -n "${i}p" $WsRootDir/gitnew.list)
	#netstat -nat|grep -i '29418' |wc -l
	echo "$i =======$a"
	#echo -e "\n" | telnet 10.0.30.10 29418 | grep Connected	
	#let i=i+1  
	#cd ~/code/MT6753/alps/"$line"
	#cd ~/code/MT6753/fanghui/hui/code_test/$line
        #echo "----$line"
	#ssh -p 29418 itadmin@10.0.30.10 gerrit create-project  Project_Tol/pk/test --parent Privilege/test 
	ssh -p 29418 $MY_NAME@10.0.30.10 gerrit create-project  $NEWPROJECTNAME/$a --parent Privilege/test
    #ssh -p 29418 itadmin@10.0.30.10 gerrit create-project XUWEITAO/WIND --parent Privilege/test
	echo "-------------"
	#echo -e "\n" | telnet 10.0.30.10 29418 | grep Connected
	#cd -
done
echo "finish creat_remote" 
}

function git_remote()
{
echo "start git_remote" 
i=1
cat $WsRootDir/project.list | while read line #
do
        a=$(sed -n "${i}p" $WsRootDir/git.list)
        echo "$line ====$a===$i" #
        let i=i+1
	    #cd ~/code/MT6753/fanghui/hui/code_test/$line  
        cd $PUSHCODEPATH/"$line"
        #ssh -p 29418 itadmin@10.0.30.10 gerrit create-project  Project_Test/$a --parent Privilege/test
        #git remote  add  origin ssh://git@bitbucket.org/owl-stealth/$a
        #git remote  set-url  --delete origin ssh://itadmin@10.0.30.10:29418/MT6753_Project/$a
        git remote  add origin  ssh://$MY_NAME@10.0.30.10:29418/$NEWPROJECTNAME/$a
        #git remote rm  origin
        git checkout -b  master
	cd - #end
done
echo "finish git_remote" 
}

function remove_git()
{
echo "start remove_git" 
cd $PUSHCODEPATH
find . -type d -name '.git' | xargs rm -rf 
cd -
echo "finish remove_git" 
}

function init_add()
{
echo "start git_init" 
i=1
cat $WsRootDir/project.list | while read LINE
do
	echo $i 
	cd $PUSHCODEPATH/"$LINE"
	#cd ~/code/MT6753/fanghui/hui/code_test/$LINE
	let "i++"
	git init
    git add -A -f
	git commit -m "init"
	cd -
done
echo "finish git_init" 
}

function git_push()
{
echo "start git_push" 
i=0
cat $WsRootDir/project.list | while read line #
do
        #a=$(sed -n "${i}p" ~/work/MT6737/shell/git_test.list)
        echo "$line===$i" #
        let i=i+1  
        cd $PUSHCODEPATH/"$line"
    # git pull origin master
    #cd ~/code/MT6753/fanghui/hui/code_test/$line
    #git checkout -b master
    git push origin   master:master
    #git push origin :Yoda_wind
    #ssh -p 29418 itadmin@10.0.30.10 gerrit create-project  Project_Test/$a --parent Privilege
    #git remote add -f origin ssh://itadmin@10.0.30.10:29418/Project_Test/$a 
    cd - 
done
echo "finish git_push" 
}

function manifest()
{

echo "start build Manifest" 
mkdir manifest
cd manifest
git init
ssh -p 29418 $MY_NAME@10.0.30.10 gerrit create-project  $NEWPROJECTNAME/Manifest --parent Privilege/test
git remote  add origin  ssh://$MY_NAME@10.0.30.10:29418/$NEWPROJECTNAME/Manifest
git add . 
git commit -m "init Manifest"
git push origin master
echo "finish build Manifest"
 
}
main $1 $2